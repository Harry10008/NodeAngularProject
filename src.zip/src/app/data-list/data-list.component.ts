import { Component, OnInit } from '@angular/core';
import { ApiService } from '../api.service';
@Component({
  selector: 'app-data-list',
  templateUrl: './data-list.component.html',
  styleUrls: ['./data-list.component.css']
})
export class DataListComponent implements OnInit{
users:any []= [];
constructor(private apiservice: ApiService) {}

  ngOnInit(): void {
  this.apiservice.getData('user/fetch').subscribe((data:any) => {
      console.log(data);
      if (data.response === 'success') {
        this.users = data.users;  // Assign users data to the users array
      }
    },
    (error) => {
      console.error('Error fetching data:', error);
    }
  );
}
}
